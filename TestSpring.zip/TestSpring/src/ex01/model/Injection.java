package ex01.model;

public interface Injection {
	String getHead();
	int getTail();
}
